history
history -w
rm -f /root/.bash_history
journalctl --rotate
journalctl --vacuum-time=1s
apt clean
sync
poweroff
hostname
chhostname TPServer
hostnamectl set-hostname TPServer
hostname
nano /etc/apt/sources.list
nano /etc/sources.list
atp update
sudo atp update
sudo apt update && apt upgrade
poweroff
apt update && apt upgrade
nano /etc/apt/sources.list
vim /etc/apt/sources.list
apt update && apt upgrade
/etc/network/interfaces
nano /etc/network/interfaces
sudo nano /etc/network/interfaces
vi /etc/network/interfaces
ip a
vi /etc/apt/sources.list
apt update 
apt update && apt upgrade
apt dist-upgrade 
apt install openssh-server
poweroff
/etc/ssh_config
/etc/ssh_idconfig
/etc/ssh_configid
/etc/ssh_ipconfig
/etc/sshd_config
/etc/ssh/sshd_config
ls -/etc/ssh
ls -etc/ssh
ls /etc/ssh
/etc/ssh/ssh_config
chmod 777 /etc/ssh/sshd_config
/etc/ssh/ssh_config
ls -ld /etc/ssh/sshd_config
/etc/ssh/ssh_config
apt install nano
nano /etc/ssh/sshd_config
nano /etc/ssh/sshd_config
ls /root
ssh_keygen -t rsa
ssh-keygen -t rsa
/root/id_rsa
ls /root/id_rsa
cd /root/id_rsa
cd /root
ls /root/id_rsa
ls
ip a
sudo systemctl status ssh
ip a
/etc/ipconfig
nano /etc/ipconfig
nano /etc/ip_config
/etc/network/interfaces
nano /etc/network/interfaces
poweroff
ipa 
ip a
ip a
ip link set enp0s3 up
ip a
ip a
sudo systemctl status ssh
/etc/network/interfaces
nano /etc/network/interfaces
ip a
nano /etc/network/interfaces
ip a
nano /etc/network/interfaces
reboot
exit
ip a
ip a
nano /etc/network/interfaces
apt install git
ls/root
ls /root
cat /root/id_rsa
nano /etc/ssh/sshd_config
systemctl restart sshd
nano /etc/ssh/sshd_config
ls -l 
cd .ssh
ls -l
mv ../id_rsa* .
ls -l
cat id_rsa.pub > authorized_keys
ls -l
cd root
ls authorized_keys 
pwd
cd /root
ls authorized_keys 
apt-get update
apt install apache2
apt update
apt install apache2
apt-get update
apt install apache2
ping 8.8.8.8
ip route
nano /etc/network/interfaces
ping 8.8.8.8
reboot
ip route
ping 8.8.8.8
apt update
apt install apache2
apt install php libapache2-mod-php
nano /etc/apache2/mods-enabled/dir.conf
nano /etc/apache2/mods-enabled/dir.conf
nano /etc/apache2/mods-enabled/dir.conf
nano /etc/apache2/mods-enabled/dir.conf
ls -l
ls
pwd
cd ssh.
cd ssh
cd .ssh
ls -l
cd ../
cd ../
cd ../
cd ../
ls 
ls -l
nano /etc/apache2/mods-enabled/dir.conf
nano index.php
ls -l
mv index.php /var/www/html/
ls -l
nano logo.png
wget https://w7.pngwing.com/pngs/897/559/png-transparent-universidad-de-palermo-hd-logo.png
ls -l
mv png-transparent-universidad-de-palermo-hd-logo.png logo.png
ls -l
mv logo.png /var/www/html/logo.png
poweroff
poweroff
apt install mariadb-server -y
systemctl restart mariadb
systemctl status mariadb
pwd
ls -l
cd Material_Adicional_TPVMCA
cd Material_Adicional_TPVMCA.tar.gz
cd Material_Adicional
ls Material_Adicional_TPVMCA.tar.gz
cd Material_Adicional_TPVMCA.tar.gz
ls Material_Adicional_TPVMCA.tar.gz
tar -tzf /root/material_adicional_tpvmca.tar.gz /root
ls -t
ls /root
tar -tzf /root/Material_Adicional_TPVMCA.tar.gz 
tar -xzf /root/material_adicional_tpvmca.tar.gz -C /root db.dql
tar -tzf /root/Material_Adicional_TPVMCA.tar.gz 
tar -xzf material_adicional_tpvmca.tar.gz -C /root 
pwd
tar -xzf material_adicional_tpvmca.tar.gz 
ls lka /root
ls la /root
tar -xzf /root/material_adicional_tpvmca.tar.gz 
ls /root
ls -t
ls -lh /root/material_adicional_tpvmca.tar.gz 
tar -xzf /root/Material_Adicional_TPVMCA.tar.gz 

cd Material_Adicional_TPVMCA.tar.gz 
cd Material_Adicional_TPVMCA
ls -l
mariadb < /root/db.sql
mariadb < db.sql
mariadb
cd -
cat /root/Material_Adicional_TPVMCA/db.sql
ip a
/etc/network/interfaces
nano /etc/network/interfaces
poweroff
poweroff
lsblk
