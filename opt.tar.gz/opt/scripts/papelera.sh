#!/bin/bash
if [ "$1" == "-help" ]; then
	echo "=== Papelera de Reciclaje ==="
	echo ""
	echo "Uso: papelera <opcion> <archivo/directorio>"
	echo ""
	echo "Opciones"
	echo "	-borrar	:  mueve el archivo o directorio a la papelera"
	echo "	-vaciar	: elimina permanentemente los archivos de la papelera"
	echo "	-listar	: muestra el contenido de la papelera"
	echo ""
	echo "Ejemplo: papelera. -mover /root/archivo.txt"
	exit 0
fi

if [ "$1" == "-borrar" ]; then
	if [ -z "$2" ]; then
		echo "Error: especifica un archivo o directorio"
		exit 1
	fi

	if [ ! -e "$2" ]; then
		echo "Error: $2 no existe"
		exit 1
	fi

	mv "$2" /papelera/
	echo "$2 movido a la papelera"
	exit 0
fi

if [ "$1" == "-vaciar" ]; then
	rm -rf /papelera/*
	echo "Papelera vaciada"
	exit 0
fi

if [ "$1" == "-listar" ]; then
	echo "=== Contenido de la papelera ==="
	ls -lh /papelera/
	exit 0
fi

if [ "$1" == "-auto" ]; then
	find /papelera/ -mtime +30 -exec rm -rf {} \;
	echo "Archivos de mas de 30 dias eliminados"
	exit 0
fi

echo "Error: opcion no valida"
echo "Ejecute papelera -help para ver las opciones"
exit 1
