#!/bin/bash

if [ "$1" == "-help" ]; then
	echo "=== Script de Backup ==="
	echo "Uso: backup_full.sh <origen> <destino>"
	echo ""
	echo "origen : directorio que queres backupear"
	echo "destino : directorio donde se va a guardar el backup"
	echo ""
	echo "Ejemplo: backup_full.sh /var/log /backup_dir"
	exit 0
fi

ORIGEN=$1
DESTINO=$2

if [ -z "$ORIGEN" ] || [ -z "$DESTINO" ]; then
	echo "Error: faltan argumentos"
	echo "Ejecuta ./backup_full.sh -help para ver como usarlo"
	exit 1
fi

if [ ! -d "$ORIGEN" ]; then
	echo "Error: el directorio origen $ORIGEN no existe"
	exit 1
fi

if [ ! -d "$DESTINO" ]; then
	echo "Error: el directorio destino $DESTINO no existe"
	exit 1
fi

FECHA=$(date +%Y%m%d)
NOMBRE=$(basename $ORIGEN)
ARCHIVO="${NOMBRE}_bkp_${FECHA}.tar.gz"

tar -czf $DESTINO/$ARCHIVO $ORIGEN

if [ $? -eq 0 ]; then
	echo "Backup generado: $DESTINO/$ARCHIVO"
else
	echo "$(date '+%Y-%m-%d %H:%M:%S') - Error al hacer backup de $ORIGEN" >> /var/log/backup_errors.log
	echo "Error al hacer backup de $ORIGEN"
	exit 1º
fi
